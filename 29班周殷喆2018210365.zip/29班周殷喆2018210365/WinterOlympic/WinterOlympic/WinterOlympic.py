#检测是否含有测试所需要的库
import plotly
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from plotly.graph_objs import *
from wordcloud import WordCloud, STOPWORDS
import colorlover as cl

#导入数据文件
f_p='athlete_events.csv'#文件默认为是已经下载好的本地文件
athlete_events=pd.read_csv(f_p)
'''
#检验数据导入情况
print(athlete_events.head())
'''
athlete=athlete_events#从今往后，athlete就是数据集
athlete = athlete[athlete['Season'] == 'Winter']#从今往后，athlete就是只含冬季奥运会项目的数据集
#统计历届冬奥会奖牌榜前10

def countmedalcountrys():
    athlete_winners = athlete[athlete.Medal.notnull()]
    winner_team = athlete_winners.groupby('Team').size().to_frame('medal_count')#采用升序排列
    winner_team = winner_team.reset_index().sort_values('medal_count',ascending=False)
    return winner_team.head(20)
#将奖牌榜绘制成图像显示
def Drawmedalcountrys(data):
    x = data['Team'].astype(str)
    y = data['medal_count'].astype(str)
    ax = data.plot.bar(x='Team',y='medal_count')
    ax.set_xlabel('Top 20')
    ax.set_ylabel('Counts')
    plt.show()
    print (data)
top20data = countmedalcountrys()
Drawmedalcountrys(top20data)

#制作冬奥会项目的词云
print(athlete_events.Sport.unique())#网上找来的历届冬季奥运会项目词库
[ 'Speed Skating'
 'Cross Country Skiing'  'Ice Hockey'  'Biathlon'  'Alpine Skiing'
  'Luge' 'Hockey''Bobsleigh' 'Figure Skating'  'Nordic Combined'
 'Freestyle Skiing' 'Rugby Sevens' 'Trampolining'
  'Triathlon' 'Ski Jumping' 'Curling' 'Snowboarding'
 'Rugby' 'Short Track Speed Skating' 'Skeleton' 'Lacrosse' 'Polo'
 'Cricket' 'Racquets' 'Motorboating' 'Military Ski Patrol' 'Croquet'
 'Jeu De Paume' 'Roque' 'Alpinism' 'Basque Pelota' 'Aeronautics']
stopwords = set(STOPWORDS)
def show_wordcloud(data, title = None):
    wordcloud = WordCloud(
        stopwords=stopwords,
        max_words=200,
        max_font_size=40, 
        scale=3,
        random_state=1 #选取一个随机位置开头
        ).generate(str(data))
    fig = plt.figure(1, figsize=(15, 15))
    plt.axis('off')
    if title: 
        fig.suptitle(title, fontsize=20)
        fig.subplots_adjust(top=2.3)
    plt.imshow(wordcloud)
    plt.show()
show_wordcloud(athlete['Sport'], title = "WordCloud")

#下面分析哪个国家在哪一届获得的奖牌最多
def countCountryMedal():
    athlete_winners=athlete[athlete.Medal.notnull()]
    winner_teams=athlete_winners.groupby(['Team','Year']).size().to_frame('medal_count').reset_index().sort_values('medal_count',ascending=False)
    return winner_teams.head(20)
print(countCountryMedal())

#参加冬奥会男女选手数量变化
def SexTrendD():
    sexathlete=athlete.groupby(["Year","Sex"]).size()
    sexathlete=sexathlete.unstack()
    ax=sexathlete.plot()
    ax.set_title("Sex")
    ax.set_xlabel("Year")
    ax.set_ylabel("Counts")
    plt.show()
    print(sexathlete)
SexTrendD()

#分析男女选手参与人数最多的项目
def MostEventsSex():
    events=athlete.groupby(["Event","Sex"]).size().sort_values(ascending=False).reset_index()
    print(events[events.Sex=='M'].head(5))
    print(events[events.Sex=='F'].head(5))
MostEventsSex()

#分析中国历届冬奥会数据
def CountryC():
    athlete_winners=athlete[athlete.Medal.notnull()]
    winner_team=athlete_winners.groupby(['Team','Year']).size().to_frame('medal_count').reset_index().sort_values('Year',ascending=False)
    winner_China=winner_team[winner_team.Team=="China"]
    return winner_China
def CountryCA():
    athlete_winners=athlete[athlete.Medal.notnull()]
    winner_team=athlete_winners.groupby(['Team','Year']).size().to_frame('medal_count').reset_index().sort_values('Year',ascending=False)
    winner_Canada=winner_team[winner_team.Team=="Canada"]
    return winner_Canada
def CountryU():
    athlete_winners=athlete[athlete.Medal.notnull()]
    winner_team=athlete_winners.groupby(['Team','Year']).size().to_frame('medal_count').reset_index().sort_values('Year',ascending=False)
    winner_USA=winner_team[winner_team.Team=="United States"]
    return winner_USA
def CountryN():
    athlete_winners=athlete[athlete.Medal.notnull()]
    winner_team=athlete_winners.groupby(['Team','Year']).size().to_frame('medal_count').reset_index().sort_values('Year',ascending=False)
    winner_Norway=winner_team[winner_team.Team=="Norway"]
    return winner_Norway
def DrawCountryDe(data):
    x = data['Year'].astype(str)
    y = data['medal_count'].astype(str)
    ax=data.plot(x='Year',y='medal_count')
    C=str(data.Team)
    ax.set_title(C)
    ax.set_xlabel('Year')
    ax.set_ylabel('Counts')
    plt.show()
    print(data)
DrawCountryDe(CountryC())
DrawCountryDe(CountryCA())
DrawCountryDe(CountryU())
DrawCountryDe(CountryN())

#分析中国男女选手在冬奥会上广泛参与的项目
def MostEventsChina():
    Cevents=athlete.groupby(["Event","Team"]).size().sort_values(ascending=False).reset_index()
    CeventsM=athlete.groupby(["Event","Team","Medal"]).size().sort_values(ascending=False).reset_index()
    print(Cevents[Cevents.Team=="China"].head(10))
    print(CeventsM[CeventsM.Team=="China"].head(10))
MostEventsChina()

#对比老牌冰雪项目强国
def compare():
    Oevents=athlete.groupby(["Event","Team"]).size().sort_values(ascending=False).reset_index()
    OeventsM=athlete.groupby(["Event","Team","Medal"]).size().sort_values(ascending=False).reset_index()
    print(Oevents[Oevents.Team=="Canada"].head(10))
    print(Oevents[Oevents.Team=="Norway"].head(10))
    print(Oevents[Oevents.Team=="United States"].head(10))
    print(OeventsM[OeventsM.Team=="Canada"].head(10))
    print(OeventsM[OeventsM.Team=="Norway"].head(10))
    print(OeventsM[OeventsM.Team=="United States"].head(10))
compare()